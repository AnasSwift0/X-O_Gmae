//
//  XoApp.swift
//  Xo
//
//  Created by Anas Salah on 05/05/2023.
//

import SwiftUI

@main
struct XoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
