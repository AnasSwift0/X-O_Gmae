//
//  ContentView.swift
//  Xo
//
//  Created by Anas Salah on 05/05/2023.
//

import SwiftUI

struct ContentView: View {
    @State private var cells = Array(repeating: "", count: 9)
    @State private var currentPlayer = "X"
    @State private var gameOver = false
    @State private var winMessage = ""
    @State private var player1Name = ""
    @State private var player2Name = ""
    @State private var player1Score = 0
    @State private var player2Score = 0
    @State private var nameIsMissing = false
    
    var body: some View {
        VStack(spacing: -10) {
            Text("Enjoy your Game🥳")
                .font(.largeTitle)
                .padding(.top, 30)
            
            HStack {
                TextField("Player 1 Name", text: $player1Name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Player 2 Name", text: $player2Name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
            }
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 5) {
                ForEach(0..<9) { index in
                    ZStack {
                        Color.blue
                            .opacity(0.3)
                            .frame(width: 100, height: 100)
                            .cornerRadius(10)
                        Text(cells[index])
                            .font(.system(size: 50))
                            .foregroundColor(.white)
                    }
                    .onTapGesture {
                        if !gameOver && cells[index].isEmpty && player1Name.count > 2 && player2Name.count > 2{
                            cells[index] = currentPlayer
                            checkForWin()
                            currentPlayer = currentPlayer == "X" ? "O" : "X"
                        } else {
                            nameIsMissing = true
                        }
                    }
                    .alert(isPresented: $nameIsMissing) {
                        Alert(title: Text("Attention 🥹"), message: Text("pleas Enter your name 👾"))
                    }
                }
            }
            .padding()
            
            Text(winMessage)
                .font(.title)
                .padding()
            HStack {
                Text("\(player1Name): \(player1Score)")
                    .padding()
                Text("\(player2Name): \(player2Score)")
                    .padding()
            }
            
            Button(action: {
                cells = Array(repeating: "", count: 9)
                currentPlayer = "X"
                gameOver = false
                winMessage = ""
            }, label: {
                Text("Restart")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            })
            .padding()
            Spacer()
        }
    }
    
    private func checkForWin() {
        let winPatterns: [[Int]] = [[0,1,2], [3,4,5], [6,7,8], [0,3,6], [1,4,7], [2,5,8], [0,4,8], [2,4,6]]
        
        for pattern in winPatterns {
            let row = [cells[pattern[0]], cells[pattern[1]], cells[pattern[2]]]
            if row == ["X", "X", "X"] {
                gameOver = true
                winMessage = "\(player1Name) Wins! 👀"
                player1Score += 1
            } else if row == ["O", "O", "O"] {
                gameOver = true
                winMessage = "\(player2Name) Wins! 🥳"
                player2Score += 1
            }
        }
        
        if !gameOver && !cells.contains("") {
            gameOver = true
            winMessage = "😡Draw"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
